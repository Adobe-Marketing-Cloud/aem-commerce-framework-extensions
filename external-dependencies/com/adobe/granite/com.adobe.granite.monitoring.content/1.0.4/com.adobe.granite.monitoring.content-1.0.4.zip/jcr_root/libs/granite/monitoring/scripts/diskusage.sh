#!/bin/bash
echo "{\"disk.capacity\":`df -k . | awk '{printf "%.0f", $2 * 1024 }' | tail -1`,
\"disk.usage\":`df -k . | awk '{ printf "%.0f", $3 * 1024 }' | tail -1` }"