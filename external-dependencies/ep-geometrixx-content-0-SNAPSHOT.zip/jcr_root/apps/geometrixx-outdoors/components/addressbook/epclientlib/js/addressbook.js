$CQ(document).ready(function() {
    var doc = $CQ(document),
        activeSelectedAddressElt,
        activeListAddressesElt,
        addressListDialog = $CQ('<div/>', {
                'class': 'select-address-dialog',
                'title': 'Manage your addresses'
            }).appendTo('body'),
        addressEditorDialog = $CQ('<div/>', {
                'class': 'update-address-dialog',
                'title': 'Manage your addresses'
            }).appendTo('body');
    addressListDialog.dialog({
        autoOpen: false,
        modal: true,
        height: 600,
        width: 500,
        zIndex: 90000
    });
    addressEditorDialog.dialog({
        autoOpen: false,
        modal: true,
        height: 600,
        width: 500,
        zIndex: 90000
    });

    // Selected Address - Select Address Link
    doc.on("click", ".select-address", function(e) {
        e.preventDefault();
        var elem = $CQ(this),
            resourcePath = elem.closest(".addressbook").data("resourcePath"),
            url = resourcePath + '.list.html';
        activeSelectedAddressElt = elem.closest(".addressbook");
        $CQ.get(url, function(html) {
            addressListDialog.html(html).dialog("open");
        });
    });

    // List Addresses - Use Address Button
    doc.on("click", ".use-address-button", function(e) {
        e.preventDefault();
        var elem = $CQ(this),
            resourcePath = elem.closest(".addressbook").data("resourcePath"),
            addressPath = elem.closest(".address").data("addressPath"),
            url = resourcePath + '.selectedaddress.html';
        $CQ.get(url, {'addressPath': addressPath}, function(html) {
            addressListDialog.dialog("close");
            // replace the address with the selected one
            if (activeSelectedAddressElt != null) {
                activeSelectedAddressElt.replaceWith($CQ(html));
            }
        });
    });

    // List Addresses - Make Default Address Button
    doc.on("click", ".make-default-address-button", function(e) {
        e.preventDefault();
        var elem = $CQ(this),
            listContainer = elem.closest(".addressbook"),
            resourcePath = elem.closest(".addressbook").data("resourcePath"),
            addressPath = elem.closest(".address").data("addressPath"),
            url = resourcePath + '.defaultaddress.html';
        $CQ.post(url, {'addressPath': addressPath}, function(html) {
            // refresh the list of addresses
            var listUrl = resourcePath + '.list.html';
            $CQ.get(listUrl, function(html) {
                listContainer.replaceWith($CQ(html));
            });
        });
    });

    // List Addresses - Delete Address Button
    doc.on("click", ".delete-address-button", function(e) {
        e.preventDefault();
        var elem = $CQ(this),
            resourcePath = elem.closest(".addressbook").data("resourcePath"),
            addressElt = elem.closest(".address"),
            addressPath = addressElt.data("addressPath"),
            url = resourcePath + '.deleteaddress.html';
        // remove from the dom
        addressElt.remove();
        // remove server side
        $CQ.post(url, {'addressPath': addressPath});
    });

    // List Addresses - Modify/Add Address Link
    doc.on("click", ".update-address-link, .add-address-link", function(e) {
        e.preventDefault();
        var elem = $CQ(this),
            resourcePath = elem.closest(".addressbook").data("resourcePath"),
            url = resourcePath + '.addresseditor.html',
            data;
        activeListAddressesElt = elem.closest(".addressbook");
        if (elem.hasClass("update-address-link")) {
            var addressPath = elem.closest(".address").data("addressPath");
            data = {'addressPath': addressPath};
        }
        $CQ.get(url, data, function(html) {
            addressEditorDialog.html(html).dialog("open");
        });
    });

    // Form - Update/Add Address Button
    doc.on("submit", "#updateorcreateaddress", function(e) {
        e.preventDefault();
        var elem = $CQ(this),
            resourcePath = elem.closest(".addressbook").data("resourcePath");
        if (address_fields_precheck("updateorcreateaddress")) {
            $CQ.post(elem.attr('action'), elem.serialize(), function(response){
                addressEditorDialog.dialog("close");
                var url = resourcePath + '.list.html';
                $CQ.get(url, function(html) {
                    if (activeListAddressesElt != null) {
                        activeListAddressesElt.replaceWith($CQ(html));
                    }
                });
            });
        }
    });

});
